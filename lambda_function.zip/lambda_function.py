"""
AWS Lambda ETL Function
This is the main function that runs in the cloud
It extracts data from APIs, transforms it, and loads to S3
"""

import json
import boto3
import urllib3
from datetime import datetime, timedelta
import hashlib
import os
import logging
from typing import Dict, List, Any, Optional
import traceback

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3_client = boto3.client('s3')
secrets_client = boto3.client('secretsmanager')

# Initialize HTTP client for API calls
http = urllib3.PoolManager()

# Environment variables
BUCKET_NAME = os.environ.get('BUCKET_NAME')
SECRET_NAME = os.environ.get('SECRET_NAME', 'data-pipeline-config')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')


def lambda_handler(event: Dict, context: Any) -> Dict:
    """
    Main Lambda handler - this is what AWS calls
    
    Args:
        event: Event data from AWS (triggers, parameters, etc.)
        context: Runtime information about the Lambda function
        
    Returns:
        Response with status code and execution results
    """
    
    # Start execution
    start_time = datetime.now()
    logger.info("=" * 60)
    logger.info("🚀 DATA PIPELINE EXECUTION STARTED")
    logger.info(f"⏰ Start Time: {start_time.isoformat()}")
    logger.info(f"📦 Bucket: {BUCKET_NAME}")
    logger.info("=" * 60)
    
    # Initialize results tracker
    results = {
        'execution_id': context.request_id if context else 'local-test',
        'start_time': start_time.isoformat(),
        'end_time': None,
        'duration_seconds': None,
        'success': True,
        'sources_processed': [],
        'total_records': 0,
        'errors': [],
        'files_created': []
    }
    
    try:
        # Step 1: Get configuration from Secrets Manager
        logger.info("\n📋 Step 1: Loading configuration...")
        config = get_configuration()
        
        if not config:
            raise Exception("Failed to load configuration from Secrets Manager")
        
        logger.info(f"   ✅ Configuration loaded")
        logger.info(f"   📊 Data sources to process: {len(config['data_sources'])}")
        
        # Step 2: Process each data source
        logger.info("\n🔄 Step 2: Processing data sources...")
        
        for source_name, source_config in config['data_sources'].items():
            logger.info(f"\n   📊 Processing {source_name.upper()}...")
            
            try:
                # Extract data from API
                raw_data = extract_data(source_name, source_config)
                
                if raw_data:
                    # Transform the data
                    transformed_data = transform_data(source_name, raw_data)
                    
                    # Load to S3
                    file_path = load_to_s3(source_name, transformed_data)
                    
                    # Update results
                    results['sources_processed'].append(source_name)
                    results['total_records'] += len(transformed_data)
                    results['files_created'].append(file_path)
                    
                    logger.info(f"   ✅ {source_name}: {len(transformed_data)} records processed")
                else:
                    logger.warning(f"   ⚠️ {source_name}: No data received")
                    
            except Exception as e:
                error_msg = f"Error processing {source_name}: {str(e)}"
                logger.error(f"   ❌ {error_msg}")
                results['errors'].append(error_msg)
                
                # Continue with other sources even if one fails
                continue
        
        # Step 3: Generate summary
        logger.info("\n📊 Step 3: Generating summary...")
        summary_path = save_execution_summary(results, config)
        results['files_created'].append(summary_path)
        
    except Exception as e:
        logger.error(f"\n❌ Fatal error: {str(e)}")
        logger.error(traceback.format_exc())
        results['success'] = False
        results['errors'].append(f"Fatal error: {str(e)}")
    
    # Calculate execution time
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    results['end_time'] = end_time.isoformat()
    results['duration_seconds'] = duration
    
    # Final summary
    logger.info("\n" + "=" * 60)
    logger.info("📈 EXECUTION SUMMARY")
    logger.info("=" * 60)
    logger.info(f"⏱️  Duration: {duration:.2f} seconds")
    logger.info(f"📊 Sources Processed: {len(results['sources_processed'])}/{len(config['data_sources'] if config else {})}")
    logger.info(f"📝 Total Records: {results['total_records']}")
    logger.info(f"📁 Files Created: {len(results['files_created'])}")
    logger.info(f"❌ Errors: {len(results['errors'])}")
    logger.info(f"✅ Status: {'SUCCESS' if results['success'] else 'FAILED'}")
    logger.info("=" * 60)
    
    # Return response
    return {
        'statusCode': 200 if results['success'] else 500,
        'body': json.dumps(results, default=str),
        'headers': {
            'Content-Type': 'application/json'
        }
    }


def get_configuration() -> Optional[Dict]:
    """
    Retrieve configuration from AWS Secrets Manager
    
    Returns:
        Configuration dictionary or None if error
    """
    try:
        response = secrets_client.get_secret_value(SecretId=SECRET_NAME)
        config = json.loads(response['SecretString'])
        return config
        
    except Exception as e:
        logger.error(f"Failed to get configuration: {e}")
        
        # Return default configuration as fallback
        return {
            'data_sources': {
                'marketing': {
                    'name': 'FakeStore API',
                    'url': 'https://fakestoreapi.com/products?limit=10',
                    'default_limit': 10
                },
                'sales': {
                    'name': 'JSONPlaceholder',
                    'url': 'https://jsonplaceholder.typicode.com/posts?_limit=10',
                    'default_limit': 10
                },
                'crm': {
                    'name': 'RandomUser API',
                    'url': 'https://randomuser.me/api/?results=10',
                    'default_limit': 10
                }
            }
        }


def extract_data(source_name: str, config: Dict) -> Optional[List]:
    """
    Extract data from an API endpoint
    
    Args:
        source_name: Name of the data source
        config: Configuration for this source
        
    Returns:
        List of records or None if error
    """
    try:
        # Build URL with limit
        url = config['url']
        if '?' in url:
            url += f"&limit={config.get('default_limit', 20)}"
        else:
            url += f"?limit={config.get('default_limit', 20)}"
        
        logger.info(f"      🔗 Fetching from: {url[:100]}...")
        
        # Make HTTP request
        response = http.request(
            'GET',
            url,
            timeout=config.get('timeout', 30),
            retries=config.get('max_retries', 3)
        )
        
        if response.status != 200:
            logger.error(f"      ❌ HTTP {response.status}")
            return None
        
        # Parse JSON response
        data = json.loads(response.data.decode('utf-8'))
        
        # Handle different response formats
        if isinstance(data, dict):
            if 'results' in data:  # RandomUser format
                return data['results']
            elif 'data' in data:  # Some APIs wrap in 'data'
                return data['data']
            elif 'products' in data:  # Some e-commerce APIs
                return data['products']
            else:
                # Single object, wrap in list
                return [data]
        elif isinstance(data, list):
            return data
        else:
            return [data]
            
    except Exception as e:
        logger.error(f"      ❌ Extract error: {e}")
        return None


def transform_data(source_name: str, raw_data: List) -> List[Dict]:
    """
    Transform raw data into standardized format
    
    Args:
        source_name: Name of the data source
        raw_data: Raw data from API
        
    Returns:
        List of transformed records
    """
    transformed = []
    
    for idx, record in enumerate(raw_data):
        # Generate unique ID
        unique_string = f"{source_name}_{idx}_{datetime.now().isoformat()}_{json.dumps(record)}"
        record_id = hashlib.md5(unique_string.encode()).hexdigest()[:12]
        
        # Create standardized record
        transformed_record = {
            'record_id': record_id,
            'source': source_name,
            'extracted_at': datetime.now().isoformat(),
            'extracted_date': datetime.now().strftime('%Y-%m-%d'),
            'raw_data': record
        }
        
        # Add source-specific transformations
        if source_name == 'marketing':
            # FakeStore product data
            transformed_record['product'] = {
                'id': record.get('id'),
                'title': record.get('title', ''),
                'price': float(record.get('price', 0)),
                'category': record.get('category', ''),
                'description': record.get('description', '')[:200],  # Limit description length
                'image': record.get('image', ''),
                'rating': record.get('rating', {})
            }
            
        elif source_name == 'sales':
            # JSONPlaceholder post data (simulated sales)
            transformed_record['sale'] = {
                'id': record.get('id'),
                'user_id': record.get('userId'),
                'title': record.get('title', ''),
                'body': record.get('body', '')[:200]
            }
            
        elif source_name == 'crm':
            # RandomUser customer data
            if 'name' in record:
                name = record['name']
                transformed_record['customer'] = {
                    'first_name': name.get('first', ''),
                    'last_name': name.get('last', ''),
                    'full_name': f"{name.get('first', '')} {name.get('last', '')}",
                    'email': record.get('email', ''),
                    'phone': record.get('phone', ''),
                    'country': record.get('location', {}).get('country', ''),
                    'city': record.get('location', {}).get('city', ''),
                    'registered_date': record.get('registered', {}).get('date', '')
                }
        
        transformed.append(transformed_record)
    
    return transformed


def load_to_s3(source_name: str, data: List[Dict]) -> str:
    """
    Load transformed data to S3
    
    Args:
        source_name: Name of the data source
        data: Transformed data to save
        
    Returns:
        S3 path where data was saved
    """
    # Generate S3 key with date partitioning
    current_date = datetime.now().strftime('%Y-%m-%d')
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    s3_key = f"data/{source_name}/date={current_date}/{source_name}_{timestamp}.json"
    
    # Add metadata
    metadata = {
        'source': source_name,
        'record_count': str(len(data)),
        'extracted_date': current_date,
        'extracted_timestamp': datetime.now().isoformat()
    }
    
    # Upload to S3
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=s3_key,
        Body=json.dumps(data, indent=2, default=str),
        ContentType='application/json',
        Metadata=metadata
    )
    
    logger.info(f"      📁 Saved to: s3://{BUCKET_NAME}/{s3_key}")
    
    return s3_key


def save_execution_summary(results: Dict, config: Dict) -> str:
    """
    Save execution summary to S3
    
    Args:
        results: Execution results
        config: Configuration used
        
    Returns:
        S3 path where summary was saved
    """
    # Create summary
    summary = {
        'execution_id': results['execution_id'],
        'execution_date': datetime.now().strftime('%Y-%m-%d'),
        'execution_time': datetime.now().isoformat(),
        'duration_seconds': results['duration_seconds'],
        'success': results['success'],
        'statistics': {
            'sources_configured': len(config.get('data_sources', {})),
            'sources_processed': len(results['sources_processed']),
            'total_records': results['total_records'],
            'files_created': len(results['files_created']),
            'errors': len(results['errors'])
        },
        'sources_processed': results['sources_processed'],
        'files_created': results['files_created'],
        'errors': results['errors']
    }
    
    # Save to S3
    current_date = datetime.now().strftime('%Y-%m-%d')
    s3_key = f"metadata/executions/date={current_date}/execution_{results['execution_id']}.json"
    
    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=s3_key,
        Body=json.dumps(summary, indent=2, default=str),
        ContentType='application/json'
    )
    
    logger.info(f"   📁 Summary saved to: s3://{BUCKET_NAME}/{s3_key}")
    
    return s3_key


# For local testing
if __name__ == "__main__":
    import sys
    
    # Set environment variables for local testing
    if not BUCKET_NAME:
        print("⚠️  Please set BUCKET_NAME environment variable")
        print("   export BUCKET_NAME=your-bucket-name")
        sys.exit(1)
    
    # Create mock context
    class MockContext:
        request_id = f"local-test-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        function_name = "data-pipeline-etl"
        function_version = "$LATEST"
        
    # Run the function
    print("🧪 Running Lambda function locally...")
    result = lambda_handler({}, MockContext())
    
    # Print results
    print("\n📊 Execution Results:")
    print(json.dumps(json.loads(result['body']), indent=2))